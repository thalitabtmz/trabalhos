package com.senai.tictactoe;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity.java
 * Jogo da Velha (Tic-Tac-Toe) - Java
 * - Dois jogadores (X e O)
 * - Controle de turno
 * - Placar para cada jogador
 * - Botões: Novo Round (limpa tabuleiro), Resetar Pontuação (zera placar + limpa)
 */

public class MainActivity extends AppCompatActivity
{
    private Button[][] boardButtons = new Button[3][3];
    private TextView tvPlayer1Score;
    private TextView tvPlayer2Score;
    private TextView tvTurn;
    private Button btnNewRound;
    private Button btnResetScores;

    private boolean player1Turn = true; // true -> X / Jogador 1
    private int roundCount = 0;
    private int score1 = 0;
    private int score2 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // TextViews e botões de controle
        tvPlayer1Score = findViewById(R.id.tvPlayer1Score);
        tvPlayer2Score = findViewById(R.id.tvPlayer2Score);
        tvTurn = findViewById(R.id.tvTurn);
        btnNewRound = findViewById(R.id.btnNewRound);
        btnResetScores = findViewById(R.id.btnResetScores);

        // Inicializa os botões do tabuleiro e seus listeners
        for (int r = 0; r < 3; r++)
        {
            for (int c = 0; c < 3; c++)
            {
                String idName = "btn" + r + c; // ex: btn00, btn01...
                int id = getResources().getIdentifier(idName, "id", getPackageName());
                boardButtons[r][c] = findViewById(id);
                final int fr = r;
                final int fc = c;
                boardButtons[r][c].setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View v)
                    {
                        onBoardButtonClick((Button) v, fr, fc);
                    }
                });
            }
        }

        btnNewRound.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                clearBoard();
            }
        });

        btnResetScores.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                score1 = 0;
                score2 = 0;
                updateScores();
                clearBoard();
            }
        });
        updateTurnText();
        updateScores();
    }

    // Quando um botão do tabuleiro é clicado
    private void onBoardButtonClick(Button button, int row, int col)
    {
        if (!button.getText().toString().equals(""))
        {
            // Já marcado
            return;
        }
        if (player1Turn)
        {
            button.setText("X");
        }
        else
        {
            button.setText("O");
        }

        roundCount++;

        if (checkForWin())
        {
            if (player1Turn)
            {
                playerWins(1);
            }
            else
            {
                playerWins(2);
            }
        }
        else if (roundCount == 9)
        {
            draw();
        }
        else
        {
            player1Turn = !player1Turn;
            updateTurnText();
        }
    }

    // Verifica se há vitória
    private boolean checkForWin()
    {
        String[][] field = new String[3][3];
        for (int r = 0; r < 3; r++)
        {
            for (int c = 0; c < 3; c++)
            {
                field[r][c] = boardButtons[r][c].getText().toString();
            }
        }

        // Linhas
        for (int i = 0; i < 3; i++)
        {
            if (!field[i][0].equals("") &&
                    field[i][0].equals(field[i][1]) &&
                    field[i][0].equals(field[i][2]))
            {
                return true;
            }
        }

        // Colunas
        for (int i = 0; i < 3; i++)
        {
            if (!field[0][i].equals("") &&
                    field[0][i].equals(field[1][i]) &&
                    field[0][i].equals(field[2][i]))
            {
                return true;
            }
        }

        // Diagonais
        if (!field[0][0].equals("") &&
                field[0][0].equals(field[1][1]) &&
                field[0][0].equals(field[2][2]))
        {
            return true;
        }
        if (!field[0][2].equals("") &&
                field[0][2].equals(field[1][1]) &&
                field[0][2].equals(field[2][0]))
        {
            return true;
        }
        return false;
    }

    // Quando um jogador vence
    private void playerWins(int player)
    {
        if (player == 1)
        {
            score1++;
            Toast.makeText(this, "Jogador 1 venceu!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            score2++;
            Toast.makeText(this, "Jogador 2 venceu!", Toast.LENGTH_SHORT).show();
        }
        updateScores();
        clearBoard();
    }

    // Empate
    private void draw()
    {
        Toast.makeText(this, "Empate!", Toast.LENGTH_SHORT).show();
        clearBoard();
    }

    // Atualiza TextViews do placar
    private void updateScores()
    {
        tvPlayer1Score.setText(String.valueOf(score1));
        tvPlayer2Score.setText(String.valueOf(score2));
    }

    // Limpa o tabuleiro para novo round (mantém placar)
    private void clearBoard()
    {
        for (int r = 0; r < 3; r++)
        {
            for (int c = 0; c < 3; c++)
            {
                boardButtons[r][c].setText("");
            }
        }
        roundCount = 0;
        player1Turn = true;
        updateTurnText();
    }

    // Atualiza indicador de vez
    private void updateTurnText()
    {
        if (player1Turn)
        {
            tvTurn.setText("Vez: Jogador 1 (X)");
        }
        else
        {
            tvTurn.setText("Vez: Jogador 2 (O)");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState)
    {
        super.onSaveInstanceState(outState);
        // Salva estado simples para rotação de tela
        outState.putInt("score1", score1);
        outState.putInt("score2", score2);
        outState.putBoolean("player1Turn", player1Turn);
        outState.putInt("roundCount", roundCount);

        // Salva conteúdo das células
        for (int r = 0; r < 3; r++)
        {
            for (int c = 0; c < 3; c++)
            {
                outState.putString("cell_" + r + c, boardButtons[r][c].getText().toString());
            }
        }
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        // Restaura estado após rotação
        score1 = savedInstanceState.getInt("score1", 0);
        score2 = savedInstanceState.getInt("score2", 0);
        player1Turn = savedInstanceState.getBoolean("player1Turn", true);
        roundCount = savedInstanceState.getInt("roundCount", 0);

        for (int r = 0; r < 3; r++)
        {
            for (int c = 0; c < 3; c++)
            {
                String value = savedInstanceState.getString("cell_" + r + c, "");
                boardButtons[r][c].setText(value);
            }
        }
        updateScores();
        updateTurnText();
    }
}